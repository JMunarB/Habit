$(document).ready(function() {
    
    /* ======= jQuery Responsive equal heights plugin ======= */
    /* Ref: https://github.com/liabru/jquery-match-height */
    
     $('#press-downloads .section-inner').matchHeight(); 
     $('#contact-methods .item-inner').matchHeight(); 
	
});



